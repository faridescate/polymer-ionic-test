core-selection
==============

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-selection) for more information.
