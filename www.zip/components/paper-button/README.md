paper-button
===================

See the [component page](http://www.polymer-project.org/docs/elements/paper-elements.html#paper-button) for more information.
