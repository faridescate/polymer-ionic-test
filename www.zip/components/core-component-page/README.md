core-component-page
===================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-component-page) for more information.

Note: this is the vulcanized version of [`core-component-page-dev`](https://github.com/Polymer/core-component-page-dev) (the source).
